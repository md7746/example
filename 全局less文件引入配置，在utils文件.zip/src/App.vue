<template>
  <div id="app">
    <div class="app-l">left</div>
    <div class="app-r">right</div>
  </div>
</template>

<script>
export default {
  name: 'App',
  data(){
    return{
      fir:'a'
    }
  },
  created(){
    
  }
}
</script>

<style lang="less" scoped>
#app{
  &{.flex();text-align:center;height: 80px;align-items: center;border: 1px solid #ccc;}
  .app-l{background:#aaa;width:100px;}
  .app-r{background:#ccc;flex: 1;}
}
</style>

