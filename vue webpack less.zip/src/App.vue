<template>
  <div id="app">
    <div class="app-l">left</div>
    <div class="app-r">right</div>
  </div>
</template>

<script>
export default {
  name: 'App',
  data(){
    return{
      fir:'a'
    }
  },
  created(){
    this.$nextTick(()=>{
      fetch('http://resource.lewanduo.cn/test/api/test.json').then(res=>{
        return res.json()
      }).then(res=>{
        this.fir = res.msg
      }).catch(err=>{
        console.log(err);
      })
    })
  }
}
</script>

<style lang="less" scoped>
*{margin:0;padding:0}
</style>

